/*
 * Freemarker template context
 *
 */

package utils.freemarker;

import java.util.HashMap;

public class FreemarkerContext extends HashMap<String, Object> {

    // Do nothing
}
